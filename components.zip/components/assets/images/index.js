export const watermark         = require('./ccar-watermark.png');





